
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import openai

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Replace with your real OpenAI key
openai.api_key = "sk-REPLACE_ME"

@app.post("/ask")
async def ask(request: Request):
    text = await request.body()
    prompt = text.decode("utf-8")

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        reply = response.choices[0].message.content.strip()
        return reply
    except Exception as e:
        return {"error": str(e)}
