# FRIDAY AI Backend

This is a FastAPI-powered backend for FRIDAY AI assistant.

### Requirements:
- FastAPI
- Uvicorn
- OpenAI

### Run Locally:
```bash
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```
